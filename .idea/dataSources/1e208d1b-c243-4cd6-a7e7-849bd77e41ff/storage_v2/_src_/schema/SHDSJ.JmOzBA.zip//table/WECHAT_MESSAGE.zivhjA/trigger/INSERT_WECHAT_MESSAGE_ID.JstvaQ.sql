create trigger INSERT_WECHAT_MESSAGE_ID
  before insert
  on WECHAT_MESSAGE
  for each row
  BEGIN
  select  seq_wechat_message_id.nextval into :new.id from dual;
END;
/

