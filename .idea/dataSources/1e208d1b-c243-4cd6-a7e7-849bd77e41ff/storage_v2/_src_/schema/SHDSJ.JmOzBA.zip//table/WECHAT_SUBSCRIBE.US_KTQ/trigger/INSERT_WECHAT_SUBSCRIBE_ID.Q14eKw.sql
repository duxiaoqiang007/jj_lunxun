create trigger INSERT_WECHAT_SUBSCRIBE_ID
  before insert or delete
  on WECHAT_SUBSCRIBE
  for each row
  BEGIN
  select  seq_wechat_subscribe_id.nextval into :new.id from dual;
END;
/

